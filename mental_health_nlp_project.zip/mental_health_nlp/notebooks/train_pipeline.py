"""
notebooks/train_pipeline.py
----------------------------
Complete end-to-end training pipeline.
Run this script to reproduce all results.

Usage:
    python notebooks/train_pipeline.py

Works in Google Colab:
    !python notebooks/train_pipeline.py
"""

import os
import sys
import logging
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import joblib

# ── Path setup ────────────────────────────────────────────────────────
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from src.preprocess import get_preprocessor
from src.features import (
    BagOfWordsExtractor, TFIDFExtractor, Word2VecExtractor,
    extract_sentiment_features, extract_linguistic_features, FeatureBuilder
)
from src.nlp_enhancements import (
    batch_emotion_scores, batch_linguistic_patterns,
    EMOTION_FEATURE_NAMES, LINGUISTIC_PATTERN_NAMES
)
from src.models import MentalHealthClassifier, evaluate_model, plot_confusion_matrix
from src.explainability import (
    plot_lr_coefficients, plot_feature_importance, plot_wordclouds
)
from data.generate_dataset import generate_dataset

from sklearn.model_selection import train_test_split
from scipy.sparse import hstack, csr_matrix

warnings.filterwarnings("ignore")
logging.basicConfig(level=logging.INFO, format="%(levelname)s — %(message)s")
logger = logging.getLogger(__name__)

# ══════════════════════════════════════════════════════════════════
# CONFIGURATION
# ══════════════════════════════════════════════════════════════════
CFG = {
    "n_samples":      3000,
    "test_size":      0.20,
    "val_size":       0.10,
    "random_state":   42,
    "max_tfidf_feat": 5000,
    "w2v_size":       100,
    "tune_models":    False,   # Set True for ~2x better results, slower
    "use_smote":      True,
    "cv_folds":       5,
    "save_dir":       os.path.join(ROOT, "models"),
    "feat_save_dir":  os.path.join(ROOT, "models", "feature_extractors"),
    "fig_save_dir":   os.path.join(ROOT, "models", "figures"),
}

os.makedirs(CFG["save_dir"], exist_ok=True)
os.makedirs(CFG["feat_save_dir"], exist_ok=True)
os.makedirs(CFG["fig_save_dir"], exist_ok=True)


def banner(title: str):
    print(f"\n{'═'*65}")
    print(f"  {title}")
    print(f"{'═'*65}")


# ══════════════════════════════════════════════════════════════════
# STEP 1: DATA
# ══════════════════════════════════════════════════════════════════
banner("STEP 1 — DATA LOADING & EXPLORATION")

data_path = os.path.join(ROOT, "data", "raw", "mental_health_dataset.csv")
os.makedirs(os.path.dirname(data_path), exist_ok=True)

if not os.path.exists(data_path):
    logger.info("Generating dataset…")
    df = generate_dataset(n_samples=CFG["n_samples"])
    df.to_csv(data_path, index=False)
else:
    df = pd.read_csv(data_path)

logger.info(f"Dataset shape: {df.shape}")
print("\nClass distribution:")
print(df["label_name"].value_counts())
print(f"\nSample texts:")
for _, row in df.sample(3, random_state=1).iterrows():
    print(f"  [{row['label_name']:10s}] {row['text'][:80]}…")


# ══════════════════════════════════════════════════════════════════
# STEP 2: PREPROCESSING
# ══════════════════════════════════════════════════════════════════
banner("STEP 2 — TEXT PREPROCESSING")

preprocessor = get_preprocessor(method="lemmatize")
logger.info("Cleaning texts…")
df["cleaned"] = preprocessor.batch_clean(df["text"].tolist())
df["tokens"]  = preprocessor.batch_tokenize(df["text"].tolist())

# Show effect of cleaning
sample_idx = df[df["label_name"] == "depression"].index[0]
print(f"\nORIGINAL: {df.loc[sample_idx, 'text']}")
print(f"CLEANED:  {df.loc[sample_idx, 'cleaned']}")

# Save processed data
proc_path = os.path.join(ROOT, "data", "processed", "cleaned_dataset.csv")
os.makedirs(os.path.dirname(proc_path), exist_ok=True)
df[["text", "cleaned", "label", "label_name"]].to_csv(proc_path, index=False)
logger.info(f"Processed data saved to {proc_path}")


# ══════════════════════════════════════════════════════════════════
# STEP 3: TRAIN/TEST SPLIT
# ══════════════════════════════════════════════════════════════════
banner("STEP 3 — TRAIN / TEST SPLIT")

X_text = df["cleaned"].tolist()
X_tokens = df["tokens"].tolist()
y = df["label"].values

X_train_text, X_test_text, X_train_tok, X_test_tok, y_train, y_test = train_test_split(
    X_text, X_tokens, y,
    test_size=CFG["test_size"],
    random_state=CFG["random_state"],
    stratify=y,
)

print(f"Train: {len(X_train_text)} | Test: {len(X_test_text)}")
print(f"Train class distribution: {dict(zip(*np.unique(y_train, return_counts=True)))}")


# ══════════════════════════════════════════════════════════════════
# STEP 4A: FEATURE COMPARISON (BoW vs TF-IDF vs W2V)
# ══════════════════════════════════════════════════════════════════
banner("STEP 4A — FEATURE EXTRACTION COMPARISON")

# Bag of Words
bow = BagOfWordsExtractor(max_features=CFG["max_tfidf_feat"])
X_bow_train = bow.fit_transform(X_train_text)
X_bow_test  = bow.transform(X_test_text)
print(f"BoW feature matrix:  {X_bow_train.shape}")

# TF-IDF
tfidf = TFIDFExtractor(max_features=CFG["max_tfidf_feat"], sublinear_tf=True)
X_tfidf_train = tfidf.fit_transform(X_train_text)
X_tfidf_test  = tfidf.transform(X_test_text)
print(f"TF-IDF feature matrix: {X_tfidf_train.shape}")

# Word2Vec
w2v = Word2VecExtractor(vector_size=CFG["w2v_size"], min_count=2)
X_w2v_train = w2v.fit_transform(X_train_tok)
X_w2v_test  = w2v.transform(X_test_tok)
print(f"Word2Vec feature matrix: {X_w2v_train.shape}")

# Quick comparison: Logistic Regression on each
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
from sklearn.preprocessing import MinMaxScaler

feat_comparison = {}
for name, X_tr, X_te in [
    ("BoW",     X_bow_train,   X_bow_test),
    ("TF-IDF",  X_tfidf_train, X_tfidf_test),
    ("Word2Vec",X_w2v_train,   X_w2v_test),
]:
    lr = LogisticRegression(max_iter=1000, class_weight="balanced", random_state=42)
    lr.fit(X_tr, y_train)
    pred = lr.predict(X_te)
    f1 = f1_score(y_test, pred, average="weighted")
    feat_comparison[name] = f1
    print(f"  {name:<12} → F1 (weighted): {f1:.4f}")

print("\nConclusion: TF-IDF generally outperforms BoW for this task,")
print("while Word2Vec captures semantic relationships but needs more data.")


# ══════════════════════════════════════════════════════════════════
# STEP 4B: FULL FEATURE MATRIX (TF-IDF + NLP enrichments)
# ══════════════════════════════════════════════════════════════════
banner("STEP 4B — BUILDING FULL FEATURE MATRIX")

def build_full_features(cleaned_texts, tokenized_texts, tfidf_vec, fit=False):
    """Build combined feature matrix used for final model training."""
    if fit:
        tfidf_feats = csr_matrix(tfidf_vec.fit_transform(cleaned_texts))
    else:
        tfidf_feats = csr_matrix(tfidf_vec.transform(cleaned_texts))

    sent  = csr_matrix(extract_sentiment_features(cleaned_texts))
    ling  = csr_matrix(extract_linguistic_features(cleaned_texts))
    patt  = csr_matrix(batch_linguistic_patterns(cleaned_texts))
    emot  = csr_matrix(batch_emotion_scores(tokenized_texts))

    return hstack([tfidf_feats, sent, ling, patt, emot]).toarray()


X_train = build_full_features(X_train_text, X_train_tok, tfidf, fit=True)
X_test  = build_full_features(X_test_text,  X_test_tok,  tfidf, fit=False)
print(f"Full feature matrix — Train: {X_train.shape}, Test: {X_test.shape}")

# Feature names for explainability
tfidf_feat_names = tfidf.get_feature_names()
sentiment_names  = ["sentiment_polarity", "sentiment_subjectivity"]
from src.features import LINGUISTIC_FEATURE_NAMES
all_feature_names = (
    tfidf_feat_names + sentiment_names + LINGUISTIC_FEATURE_NAMES
    + LINGUISTIC_PATTERN_NAMES + EMOTION_FEATURE_NAMES
)
print(f"Total named features: {len(all_feature_names)}")

# Save TF-IDF vectorizer
joblib.dump(tfidf.vectorizer, os.path.join(CFG["feat_save_dir"], "tfidf.pkl"))
logger.info("TF-IDF vectorizer saved.")


# ══════════════════════════════════════════════════════════════════
# STEP 5: MODEL TRAINING & COMPARISON
# ══════════════════════════════════════════════════════════════════
banner("STEP 5 — TRAINING & COMPARING ALL MODELS")

trainer = MentalHealthClassifier(
    use_smote=CFG["use_smote"],
    cv_folds=CFG["cv_folds"],
)
results = trainer.train_all(
    X_train, y_train, X_test, y_test,
    tune=CFG["tune_models"],
)


# ══════════════════════════════════════════════════════════════════
# STEP 6: LEADERBOARD & EVALUATION
# ══════════════════════════════════════════════════════════════════
banner("STEP 6 — MODEL LEADERBOARD")

leaderboard_df = trainer.print_leaderboard()

# Save leaderboard
leaderboard_path = os.path.join(CFG["save_dir"], "leaderboard.csv")
leaderboard_df.to_csv(leaderboard_path, index=False)
print(f"\nLeaderboard saved to {leaderboard_path}")

# Plot confusion matrix for best model
best_name = trainer.best_model_name
best_preds = results[best_name]["y_pred"]
cm_path = os.path.join(CFG["fig_save_dir"], "confusion_matrix_best.png")
plot_confusion_matrix(y_test, best_preds, model_name=best_name, save_path=cm_path)

# Visualise feature comparison
fig, ax = plt.subplots(figsize=(7, 4))
feat_names = list(feat_comparison.keys())
feat_vals  = list(feat_comparison.values())
bars = ax.bar(feat_names, feat_vals, color=["#3498db", "#2ecc71", "#e74c3c"], edgecolor="white", width=0.5)
ax.set_ylabel("F1 Score (Weighted)")
ax.set_title("Feature Representation Comparison (Logistic Regression)", fontweight="bold")
ax.set_ylim(0, 1)
for bar, val in zip(bars, feat_vals):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
            f"{val:.3f}", ha="center", fontweight="bold")
plt.tight_layout()
plt.savefig(os.path.join(CFG["fig_save_dir"], "feature_comparison.png"), dpi=150)
plt.show()


# ══════════════════════════════════════════════════════════════════
# STEP 7: EXPLAINABILITY
# ══════════════════════════════════════════════════════════════════
banner("STEP 7 — EXPLAINABILITY")

# Word clouds
plot_wordclouds(
    X_train_text, y_train,
    save_path=os.path.join(CFG["fig_save_dir"], "wordclouds.png")
)

# LR coefficients (if LR is best or available)
if "Logistic Regression" in trainer.trained_models:
    lr_model = trainer.trained_models["Logistic Regression"]
    plot_lr_coefficients(
        lr_model,
        all_feature_names[:CFG["max_tfidf_feat"]],  # only TF-IDF names fit coef_ shape
        save_path=os.path.join(CFG["fig_save_dir"], "lr_coefficients.png")
    )

# Random Forest feature importance
if "Random Forest" in trainer.trained_models:
    rf_model = trainer.trained_models["Random Forest"]
    plot_feature_importance(
        rf_model,
        all_feature_names,
        model_name="Random Forest",
        save_path=os.path.join(CFG["fig_save_dir"], "rf_feature_importance.png")
    )


# ══════════════════════════════════════════════════════════════════
# STEP 8: SAVE BEST MODEL
# ══════════════════════════════════════════════════════════════════
banner("STEP 8 — SAVING BEST MODEL")

trainer.save_best_model(CFG["save_dir"])
trainer.save_all_models(CFG["save_dir"])
print(f"\n✅ All models and artifacts saved to: {CFG['save_dir']}")


# ══════════════════════════════════════════════════════════════════
# STEP 9: QUICK INFERENCE TEST
# ══════════════════════════════════════════════════════════════════
banner("STEP 9 — INFERENCE DEMO")

LABEL_NAMES = ["Normal", "Depression", "Anxiety"]

test_examples = [
    "I can't stop crying, everything feels pointless and I'm so tired all the time.",
    "Had an amazing hike today with friends! The weather was perfect.",
    "My heart won't stop racing, I keep imagining the worst possible scenarios.",
]

best_model = trainer.get_best_model()

for text in test_examples:
    cleaned = preprocessor.clean(text)
    tokens = preprocessor.tokenize(text)
    X_demo = build_full_features([cleaned], [tokens], tfidf, fit=False)
    pred = best_model.predict(X_demo)[0]
    label = LABEL_NAMES[pred]
    if hasattr(best_model, "predict_proba"):
        proba = best_model.predict_proba(X_demo)[0]
        conf = f"{proba[pred]*100:.1f}%"
    else:
        conf = "N/A"
    print(f"\nText:       {text[:70]}…")
    print(f"Prediction: {label} (confidence: {conf})")


banner("PIPELINE COMPLETE ✅")
print(f"Best model:   {trainer.best_model_name}")
print(f"Best F1:      {results[trainer.best_model_name]['f1_score']:.4f}")
print(f"\nNext step: streamlit run app/streamlit_app.py")
