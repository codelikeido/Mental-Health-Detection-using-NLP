# 🧠 Mental Health NLP — Depression & Anxiety Detection from Social Media Text

[![Python](https://img.shields.io/badge/Python-3.8%2B-blue?logo=python)](https://python.org)
[![scikit-learn](https://img.shields.io/badge/scikit--learn-1.3-orange?logo=scikit-learn)](https://scikit-learn.org)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.25-red?logo=streamlit)](https://streamlit.io)
[![License: MIT](https://img.shields.io/badge/License-MIT-green)](LICENSE)

> **An end-to-end NLP pipeline to detect signs of depression and anxiety from social media text — built as a complete ML project from data collection to deployment.**

---

## 📌 Problem Statement

Mental health conditions like depression and anxiety often go undetected because individuals express distress in subtle, non-clinical language on social media. Traditional keyword-based tools miss context, sarcasm, and the semantic richness of natural language.

This project builds a **production-grade NLP classifier** that goes beyond keywords — using semantic embeddings, sentiment analysis, emotion lexicons, and multiple ML models — to classify social media text into:

| Label | Description |
|-------|-------------|
| ✅ Normal | Neutral or positive expression |
| 💙 Depression | Hopelessness, withdrawal, low energy, worthlessness |
| 🌊 Anxiety | Worry, panic, hypervigilance, racing thoughts |

---

## 🏗️ Project Structure

```
mental_health_nlp/
├── data/
│   ├── generate_dataset.py      # Simulated Reddit-style dataset generator
│   ├── raw/                     # Raw CSV data
│   └── processed/               # Cleaned & preprocessed data
│
├── src/
│   ├── preprocess.py            # Full text cleaning pipeline
│   ├── features.py              # BoW, TF-IDF, Word2Vec extractors
│   ├── nlp_enhancements.py      # NER, emotion lexicons, linguistic patterns
│   ├── models.py                # All 7 classifiers + training framework
│   └── explainability.py        # SHAP, feature importance, word clouds
│
├── notebooks/
│   └── train_pipeline.py        # Master training script (run this!)
│
├── app/
│   └── streamlit_app.py         # Web application for live predictions
│
├── models/
│   ├── best_model.pkl           # Saved best model
│   ├── leaderboard.csv          # Model comparison results
│   ├── feature_extractors/      # Saved TF-IDF, Word2Vec
│   └── figures/                 # Plots, confusion matrices
│
├── requirements.txt
└── README.md
```

---

## ⚙️ Tech Stack

| Component | Library |
|-----------|---------|
| NLP / Preprocessing | NLTK, spaCy, contractions |
| Feature Extraction | scikit-learn (TF-IDF, BoW), Gensim (Word2Vec) |
| Sentiment Analysis | TextBlob |
| ML Models | scikit-learn, XGBoost |
| Class Imbalance | imbalanced-learn (SMOTE) |
| Explainability | SHAP, matplotlib |
| Visualization | seaborn, WordCloud |
| Deployment | Streamlit |

---

## 🚀 Quick Start

### 1. Clone & Install

```bash
git clone https://github.com/yourusername/mental-health-nlp.git
cd mental-health-nlp
pip install -r requirements.txt
python -m spacy download en_core_web_sm
```

### 2. Train the Pipeline

```bash
python notebooks/train_pipeline.py
```

This will:
- Generate/load the dataset
- Clean and preprocess all texts
- Extract BoW, TF-IDF, and Word2Vec features
- Train and compare 7 ML models
- Save the best model and all artifacts
- Generate visualizations (word clouds, confusion matrix, feature importance)

### 3. Launch the Web App

```bash
streamlit run app/streamlit_app.py
```

Open `http://localhost:8501` in your browser.

### Google Colab

```python
!git clone https://github.com/yourusername/mental-health-nlp.git
%cd mental-health-nlp
!pip install -r requirements.txt -q
!python -m spacy download en_core_web_sm -q
!python notebooks/train_pipeline.py
```

---

## 🔬 Approach & Methodology

### 1. Data Handling

- **Dataset**: Simulated Reddit-style posts (replace with SMHD or CLPsych in production)
- **Cleaning**: URL/mention removal, emoji handling, slang normalization, contraction expansion
- **Normalization**: Lowercasing, lemmatization, stopword removal (preserving negation words)
- **Class Imbalance**: SMOTE oversampling on training set + `class_weight="balanced"`

### 2. Feature Engineering

Three representations are implemented and compared:

| Method | Type | Pros | Cons |
|--------|------|------|------|
| **Bag of Words** | Sparse, frequency | Fast, interpretable | Ignores word importance |
| **TF-IDF** | Sparse, weighted | Rewards discriminative words | No semantic meaning |
| **Word2Vec** | Dense, semantic | Captures context & synonyms | Needs large corpus |

**Winner**: TF-IDF + NLP enrichments (sentiment + emotion + linguistic patterns)

### 3. NLP Enrichments

- **Sentiment Analysis** (TextBlob): polarity and subjectivity scores
- **Emotion Lexicons**: sadness, fear/anxiety, anger, joy, disgust scores
- **Linguistic Patterns**: absolutist thinking ratio, hedging words, first-person pronouns, negation density
- **Named Entity Recognition** (spaCy): entity type counts as social context signals

### 4. Model Training

7 classifiers trained and compared:

| Model | Notes |
|-------|-------|
| Logistic Regression | Strong baseline, interpretable via coefficients |
| Naive Bayes (Complement) | Fast, works well with text |
| SVM (LinearSVC) | Often best for high-dimensional text |
| Random Forest | Ensemble, handles non-linearity |
| Gradient Boosting | Sequential boosting, often top performer |
| XGBoost | State-of-art gradient boosting |
| MLP Neural Net | Shallow neural baseline |

All models use:
- Stratified 5-fold cross-validation
- Weighted precision/recall/F1 for class imbalance
- RandomizedSearchCV for hyperparameter tuning (optional)

---

## 📊 Results

Sample results on test set (actual numbers vary by run):

| Model | Accuracy | F1 (weighted) | CV F1 |
|-------|----------|---------------|-------|
| SVM (Linear) | ~0.84 | ~0.84 | ~0.82 |
| Logistic Regression | ~0.83 | ~0.83 | ~0.81 |
| XGBoost | ~0.82 | ~0.82 | ~0.80 |
| Random Forest | ~0.80 | ~0.80 | ~0.78 |
| Gradient Boosting | ~0.80 | ~0.80 | ~0.78 |
| MLP Neural Net | ~0.79 | ~0.79 | ~0.77 |
| Naive Bayes | ~0.75 | ~0.75 | ~0.73 |

**Best model**: LinearSVC or Logistic Regression (typically)

**Why SVM/LR wins**: TF-IDF produces high-dimensional sparse vectors; linear models are well-suited for this space and outperform tree-based methods which struggle with sparsity.

---

## 🔍 Explainability

- **Logistic Regression coefficients**: Shows top words per class (e.g., "hopeless", "worthless" → depression)
- **Random Forest feature importance**: Gini-based ranking across all features
- **SHAP values**: Model-agnostic attribution for individual predictions
- **Word clouds**: Visual representation of vocabulary per class

---

## ⚠️ Ethical Considerations

This project raises important ethical questions about AI in mental health:

1. **Not a diagnostic tool**: This model should never replace clinical assessment. Mental health diagnosis requires qualified professionals, clinical interviews, and longitudinal observation.

2. **Bias in training data**: Social media text skews toward specific demographics, writing styles, and cultural expressions. The model may underperform for non-English speakers, older adults, or people from different cultural backgrounds.

3. **False positives/negatives**: A false positive (flagging a healthy person) can cause unnecessary distress. A false negative (missing someone in crisis) can have serious consequences. Neither error is acceptable in clinical settings.

4. **Privacy**: Analysing social media text for mental health indicators without consent raises significant privacy and ethical concerns.

5. **Misuse potential**: This tool could be misused to profile or discriminate against individuals. Any deployment must include strict access controls and ethical oversight.

> **The goal of this project is educational** — to demonstrate NLP and ML techniques in a meaningful domain, and to encourage thinking about responsible AI.

---

## 🔮 Future Improvements

- [ ] Fine-tune BERT/RoBERTa on clinical mental health datasets
- [ ] Multi-label classification (comorbidities are common)
- [ ] Temporal analysis — detect change over time in a user's posts
- [ ] Multilingual support
- [ ] Integration with validated mental health scales (PHQ-9, GAD-7)
- [ ] Active learning loop for continuous improvement
- [ ] Proper deployment with authentication and audit logging

---

## 📚 References & Datasets

- [SMHD Dataset — CLPsych](https://ir.cs.georgetown.edu/resources/smhd.html)
- [Reddit Mental Health Dataset — Kaggle](https://www.kaggle.com/datasets/kamaruladha/mental-health-classification)
- [CLPsych Shared Tasks](https://clpsych.org/shared-tasks/)
- Coppersmith et al. (2014) — *Quantifying Mental Health Signals in Twitter*

---

## 👤 Author

Built as a portfolio project demonstrating full ML pipeline skills in NLP and responsible AI.

---

## 📄 License

MIT License — see [LICENSE](LICENSE) for details.
